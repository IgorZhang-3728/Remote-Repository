<template>
	<div class="page-layout">
		<el-container>
			<el-main class="main_panel" style="" :style="{height:(height-61)+'px'}">
				<router-view @logined='logined' :userinfo="userinfo" style=""></router-view>
			</el-main>
			<el-header v-if="islogin"
				style="border-left: 1px solid #040404ad;background-color: #000;box-shadow: rgb(0 0 0 / 8%) 0px 5px 5px 5px;z-index: 1;position: fixed;top:0px;left:0px;width:100%;height:60px">
				<TopBar @loginout='loginout' :userinfo="userinfo"></TopBar>
			</el-header>
		</el-container>
	</div>
</template>
<script>
	import utils from "./public/utils.js";
	import api from "./public/api.js";
	import $ from 'jquery';

	import TopBar from "./components/TopBar.vue";

	export default {
		components: {
			TopBar
		},
		data() {
			return {
				//默认非登录状态,检测登录状态，并跳转到对于界面,
				islogin: utils.islogined(),
				height: $(window).height(),
				width: $(window).width() - 20,
				userinfo: null
			}
		},
		watch: {},
		mounted: function() {
			this.height = $(window).height();
			if (this.islogin) {
				this.loadUserInfo();
			}
		},
		methods: {
			logined: function() {
				this.islogin = utils.islogined();
				this.$router.push("Index");

				this.loadUserInfo();

				this.$forceUpdate();
			},
			loginout: function() {
				this.islogin = utils.islogined();
				this.$router.push("Login");

				this.$forceUpdate();
			},
			loadUserInfo: function() {
				var that = this;
				api.loadUserInfoData(function(res) {
					if (!res || res.status != 200 || !res.data) {
						utils.showerror("信息加载失败！");
						return;
					}
					that.userinfo = res.data;
				});
			}
		}
	}
</script>

<style>
	.page-layout .el-main {
		padding-top: 10px !important;
		padding-left: 10px !important;
		padding-right: 10px !important;
		padding-bottom: 10px !important;
		overflow: hidden;
	}

	.el-header .el-main {
		padding: 0 !important;
	}

	.page-layout .el-header {
		padding: 0;
	}

	.container {
		height: v-bind(height+"px");
	}

	.menubar {
		overflow: hidden !important;
	}

	.main_panel {
		z-index: 1;
		background: #f8f8f8;
		padding-left: 10px;
		padding-right: 10px;
		padding-top: 10px;
		overflow: hidden;
		width:v-bind(width+'px');
		position: fixed;
		top: 60px;
		left: 0px;
	}
</style>
